<?php
require_once '../engine/bootstrap.php';

//Init Core Library
$init = new Core;